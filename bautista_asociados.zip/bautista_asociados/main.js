document.addEventListener('DOMContentLoaded', () => {
    console.log("Página lista con animaciones.");

    // Si hay conexión, reemplaza íconos locales por Lucide CDN
    if (navigator.onLine) {
        console.log("Conexión detectada: usando íconos Lucide CDN");
        const iconMap = {
            "phone.svg": "lucide lucide-phone",
            "mail.svg": "lucide lucide-mail",
            "map-pin.svg": "lucide lucide-map-pin",
            "shield.svg": "lucide lucide-shield",
            "users.svg": "lucide lucide-users",
            "briefcase.svg": "lucide lucide-briefcase",
            "scale.svg": "lucide lucide-scale",
            "landmark.svg": "lucide lucide-landmark",
            "home.svg": "lucide lucide-home"
        };

        document.querySelectorAll('img[src*="/img/"]').forEach(img => {
            const fileName = img.src.split('/').pop();
            if (iconMap[fileName]) {
                const iconElement = document.createElement("i");
                iconElement.className = iconMap[fileName];
                iconElement.style.width = img.width + "px";
                iconElement.style.height = img.height + "px";
                img.replaceWith(iconElement);
            }
        });

        // Cargar script Lucide
        const lucideScript = document.createElement("script");
        lucideScript.src = "https://unpkg.com/lucide@latest";
        lucideScript.onload = () => lucide.createIcons();
        document.body.appendChild(lucideScript);
    } else {
        console.log("Sin conexión: usando íconos locales");
    }
});
